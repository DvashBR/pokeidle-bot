// Roda em cada janela ANTES do jogo. Observa o WebSocket do próprio jogo.
const { ipcRenderer: ipc } = require('electron');
const conta = Number((process.argv.find((a) => a.startsWith('--conta=')) || '').split('=')[1]) || 0;
const cfgAtual = () => ipc.sendSync('cfg');
const emit = (o) => ipc.send('evt', { conta, ...o });

let jogo = null;                 // WebSocket do jogo
const ultimo = {};               // último pedido market.listar de pokémon feito na tela
const tentados = new Map();      // anúncios que já tentei comprar (id -> quando)
const amostrados = new Set();
let tentCat = 0;
const gastoItem = {};
let gasto = 0, compras = 0, itensEnviados = false;

const WS = window.WebSocket;
window.WebSocket = new Proxy(WS, {
  construct(alvo, args) {
    const w = new alvo(...args);
    jogo = w;
    const enviarOrig = w.send.bind(w);
    w.send = (d) => {
      try {
        const m = JSON.parse(d);
        if (m.t === 'market.listar' && m.tipo === 'pokemon') ultimo.pk = m;
      } catch {}
      return enviarOrig(d);
    };
    w.addEventListener('message', (ev) => { try { receber(ev.data); } catch (e) { emit({ texto: 'erro: ' + e.message }); } });
    return w;
  },
});
const mandar = (o) => jogo && jogo.readyState === 1 && jogo.send(JSON.stringify(o));

// ---- leitura -------------------------------------------------------------
const num = (...v) => v.map(Number).find((x) => Number.isFinite(x) && x !== 0);
function achaShinies(o, origem, prof = 0) {
  if (!o || typeof o !== 'object' || prof > 7) return;
  if (o.shiny === true && (o.nome || o.especie)) {
    emit({ tipo: 'shiny', origem, id: String(o.id ?? o.uid ?? `${o.nome ?? o.especie}:${o.level ?? ''}:${o.criadoEm ?? ''}`),
           nome: o.nome ?? o.especie, nivel: o.level });
  }
  for (const v of Object.values(o)) achaShinies(v, origem, prof + 1);
}
const notaCache = new Map();
function notaDe(a) {   // o anúncio não traz a nota: o próprio cliente do jogo a calcula a partir da ficha
  const f = a.ficha ?? a;
  const direta = num(a.nota, f.nota, a.notaMercado, f.notaMercado);
  if (direta != null) return direta;
  if (f.speciesId == null) return null;
  const k = a.id ?? null;
  if (k != null && notaCache.has(k)) return notaCache.get(k);
  let n = null;
  try { n = ipc.sendSync('nota', f); } catch {}
  if (k != null && n != null) { notaCache.set(k, n); if (notaCache.size > 5000) notaCache.delete(notaCache.keys().next().value); }
  return n;
}
const alertados = new Set();
function checarAlerta(a, c) {
  const f = a.ficha ?? a;
  const nota = notaDe(a);
  if (nota == null || nota < c.notaMin || alertados.has(a.id)) return;
  const preco = Number(a.preco) * (Number(a.qtd) || 1);
  const ok = a.moeda === 'orb' ? preco <= c.maxGemas : preco <= c.maxCoins;
  if (!ok) return;
  alertados.add(a.id);
  emit({ tipo: 'alerta', texto: `${f.nome ?? 'Pokémon'}${f.shiny ? ' ✨' : ''} nota ${nota} por ${preco} ${a.moeda === 'orb' ? 'gemas' : 'coins'}` });
}
function tentarComprar(a, pedra, c) {
  if (a.moeda !== 'gold' || Number(a.preco) > pedra.maxPreco) return;
  if (a.compravelEm && Date.now() < a.compravelEm + 1500) return;  // retenção anti-snipe
  if (tentados.has(a.id)) return;
  const orcItem = Number(pedra.gastoMax) > 0 ? Number(pedra.gastoMax) - (gastoItem[pedra.itemId] || 0) : Infinity;
  const qtd = Math.min(a.qtd || 1, Math.floor(Math.min(c.gastoMaxSessao - gasto, orcItem) / a.preco), c.maxCompras - compras);
  if (qtd < 1) return;
  tentados.set(a.id, Date.now());
  gasto += qtd * a.preco; compras += qtd; gastoItem[pedra.itemId] = (gastoItem[pedra.itemId] || 0) + qtd * a.preco;
  mandar({ t: 'market.comprar', id: a.id, qtd, preco: a.preco, moeda: a.moeda });
  emit({ texto: `🛒 pedido: ${qtd}x ${pedra.nome} a ${a.preco} (gasto ${gasto}/${c.gastoMaxSessao})` });
}
function receber(raw) {
  if (typeof raw !== 'string') return;
  try { coletar(raw); } catch (e) { emit({ texto: 'coleta: ' + e.message }); }
  if (raw.includes('"shiny":true') && !raw.startsWith('{"t":"campo"')) {
    const m = JSON.parse(raw); achaShinies(m, m.t);
  }
  if (!raw.startsWith('{"t":"market"')) return;
  const m = JSON.parse(raw);
  const cfg = cfgAtual();
  if (m.aba === 'itens' && m.resumo && !itensEnviados && conta === cfg.compra.conta) {
    itensEnviados = true; emit({ tipo: 'itens', resumo: m.resumo });
  }
  const linhas = m.linhas ?? [];
  const chaveAm = m.aba ?? 'x';
  if (!amostrados.has(chaveAm)) {
    amostrados.add(chaveAm);
    const am = { ...m, linhas: linhas.slice(0, 2) };
    if (am.resumo) am.resumo = Object.fromEntries(Object.entries(am.resumo).slice(0, 3));
    emit({ tipo: 'amostra', aba: chaveAm, amostra: am });
  }
  if (linhas.length) {
    const nt = linhas.map((a) => notaDe(a)).filter((x) => x != null);
    emit({ tipo: 'stat', aba: m.aba, n: linhas.length, notaMax: nt.length ? Math.max(...nt) : null });
  }
  if (cfg.alerta.ativo && conta === cfg.alerta.conta) linhas.forEach((a) => checarAlerta(a, cfg.alerta));
  if (cfg.compra.ativo && conta === cfg.compra.conta && m.aba === 'item') {
    const p = cfg.compra.pedras.find((x) => String(x.itemId) === String(m.itemId));
    if (p) linhas.sort((x, y) => x.preco - y.preco).forEach((a) => tentarComprar(a, p, cfg.compra));
  }
}

// ---- botões dentro de cada tela: ⤢ maximiza/volta à grade, "C1" identifica a conta ----
window.addEventListener('DOMContentLoaded', () => {
  const base = 'position:fixed;top:6px;z-index:2147483647;color:#fff;background:#000a;border:0;border-radius:6px;';
  const b = document.createElement('button');
  b.textContent = '⤢'; b.title = 'Maximizar / voltar à grade';
  b.style.cssText = base + 'right:6px;font-size:22px;padding:2px 10px;opacity:.55;cursor:pointer';
  b.onmouseenter = () => (b.style.opacity = 1); b.onmouseleave = () => (b.style.opacity = 0.55);
  b.onclick = () => ipc.send('toggle', conta);
  const tag = document.createElement('div');
  tag.textContent = 'C' + conta;
  tag.style.cssText = base + 'left:6px;font:700 14px system-ui;padding:4px 8px;opacity:.6;pointer-events:none';
  document.body.append(b, tag);
});

// ---- consulta periódica (com jitter) ---------------------------------------
let rodada = 0;
function tick() {
  const cfg = cfgAtual();
  if (!itensEnviados && conta === cfg.compra.conta && tentCat++ % 4 === 0) mandar({ t: 'market.itens', elemento: '', categoria: '' });
  if (cfg.alerta.ativo && conta === cfg.alerta.conta && ultimo.pk) mandar({ ...ultimo.pk, pagina: paginaVarredura() });
  if (cfg.compra.ativo && conta === cfg.compra.conta) {
    const ps = cfg.compra.pedras.filter((p) => p.itemId && !String(p.itemId).startsWith('COLOQUE'));
    if (ps.length) mandar({ t: 'market.item', itemId: ps[rodada++ % ps.length].itemId, moeda: 'gold' });
  }
  for (const [id, t] of tentados) if (Date.now() - t > 60000) tentados.delete(id);
  setTimeout(tick, cfg.pollMs * (0.8 + Math.random() * 0.5));
}


// ======================= COLETA E ANÁLISE =======================
const coletaCfg = () => ({ ativo: true, conta: 1, pvpMinutos: 30, ...(cfgAtual().coleta ?? {}) });
const souColeta = () => { const c = coletaCfg(); return c.ativo && c.conta === conta; };
let mapaAtual = null, ultimaAtiv = 0, varre = 0, ultimoPvp = 0;
const porMapa = {};
const cel = (s) => (porMapa[s || 'desconhecido'] ??= { segundos: 0, abates: 0, xp: 0, ouro: 0, drops: {}, capturas: 0, fugas: 0, shinies: 0, esp: {} });
const amostrou = new Set();
const amostra = (nome, o) => { if (!amostrou.has(nome)) { amostrou.add(nome); emit({ tipo: 'amostra', aba: nome, amostra: o }); } };
const limpa = (o) => JSON.parse(JSON.stringify(o ?? {}, (k, v) => (k === 'looktype' || k === 'vs' || k === 'sprite' ? undefined : v)));
const dado = (canal, d) => emit({ tipo: 'dado', canal, d });
// Na busca de pokémon do Market: quase sempre a página 1 (alerta rápido), de vez em quando 2-4 (amostra maior).
const paginaVarredura = () => (varre++ % 4 === 3 ? 2 + (Math.floor(varre / 4) % 3) : 1);

let nomeVisto = null;
const espDe = (s, n) => ((s.esp ??= {})[n ?? '?'] ??= { ab: 0, cap: 0, fug: 0, bolas: 0, ok: 0 });
function aoBatalha(m) {
  const s = cel(mapaAtual);
  for (const e of m.ev ?? []) {
    if (e.k === 'spawn') nomeVisto = e.nome ?? e.pokemon?.nome ?? nomeVisto;
    else if (e.k === 'morte' && e.quem === 'selvagem') {
      amostra('morte', limpa(e));
      nomeVisto = e.nome ?? nomeVisto;
      s.abates++; espDe(s, e.nome).ab++;
      s.xp += Number(e.xpTreinador ?? e.xp) || 0;
      s.ouro += (Number(e.ouro) || 0) + (Number(e.ouroVendaAuto) || 0);
      for (const d of e.drops ?? []) { const n = d.nome ?? d.itemId; s.drops[n] = (s.drops[n] || 0) + (Number(d.qtd) || 1); }
      ultimaAtiv = Date.now();
    } else if (e.k === 'bola') {
      const x = espDe(s, nomeVisto); x.bolas++; if (e.sucesso) x.ok++;
      ultimaAtiv = Date.now();
    } else if (e.k === 'capturado') {
      s.capturas++; espDe(s, e.pokemon?.nome).cap++; ultimaAtiv = Date.now(); amostra('capturado', limpa(e));
      if (e.pokemon?.shiny) { s.shinies++; dado('shiny', { fonte: 'propria', nick: `(conta ${conta})`, p: limpa(e.pokemon), mapa: mapaAtual, ts: Date.now() }); }
    } else if (e.k === 'fugiu') { s.fugas++; espDe(s, e.nome).fug++; }
  }
}
function registrarMercado(m) {
  const linhas = m.linhas ?? [];
  if (!linhas.length) return;
  dado('mercado', linhas.map((a) => {
    const f = a.ficha ?? {};
    return { id: a.id, nome: f.nome ?? f.especie ?? a.nome ?? null, itemId: a.itemId ?? m.itemId ?? null, item: a.itemNome ?? a.nomeItem ?? null,
      nota: notaDe(a) ?? null, nivel: f.level ?? null, shiny: !!(f.shiny ?? a.shiny),
      preco: a.preco, qtd: a.qtd, moeda: a.moeda, ts: Date.now() };
  }));
}
let pvpFila = [], pvpTimer = null;
function pedirPvp() {
  ultimoPvp = Date.now();
  mandar({ t: 'ranking.pedir', aba: 'elo' });
  setTimeout(() => mandar({ t: 'ranking.pedir', aba: 'poder' }), 2500);
}
function agendarPerfis() {
  if (pvpTimer) return;
  pvpTimer = setInterval(() => {
    const nick = pvpFila.shift();
    if (!nick) { clearInterval(pvpTimer); pvpTimer = null; return; }
    mandar({ t: 'ranking.perfil', nick });
  }, 4000);   // um perfil a cada 4 s, para não pesar no servidor
}
function coletar(raw) {
  const tp = (raw.slice(0, 48).match(/"t":"([^"]+)"/) || [])[1];
  if (!tp || tp === 'campo' || tp === 'pong') return;
  if (tp === 'estado' || tp === 'welcome') {
    const mm = raw.match(/"huntSlug":(null|"[^"]*")/);
    if (mm) mapaAtual = JSON.parse(mm[1]);
    if (tp === 'welcome' && souColeta()) {
      try { const w = JSON.parse(raw); dado('captura_cfg', { captura: w.captura, nossos: (w.itensNossos ?? []).map(prim) }); } catch {}
    }
    return;
  }
  if (tp === 'batalha') return aoBatalha(JSON.parse(raw));
  if (!['market', 'shiny.captura', 'chat', 'ranking', 'perfil'].includes(tp)) return;
  const m = JSON.parse(raw);
  if (tp === 'market') { amostrarPiso(m); return registrarMercado(m); }
  if (!souColeta()) return;
  if (tp === 'shiny.captura') {
    amostra('shiny_captura', limpa(m));
    dado('shiny', { fonte: 'global', nick: m.nick, p: limpa(m.pokemon), mapa: m.mapa ?? m.pokemon?.mapa ?? null, ts: Date.now() });
  } else if (tp === 'chat') {
    if (m.shinyCaptura) {
      const sc = typeof m.shinyCaptura === 'object' ? (m.shinyCaptura.pokemon ?? m.shinyCaptura) : {};
      dado('shiny', { fonte: 'chat', nick: m.de, p: limpa(sc), texto: m.texto, ts: Date.now() });
    } else if (m.dropLendario) { amostra('drop_lendario', limpa(m)); dado('dropLendario', { ...limpa(m), ts: Date.now() }); }
    else if (m.texto && !m.pvpEntrada && !m.anuncioChat && !m.conviteResgate) {
      dado('chat', { canal: m.canal, de: m.de, texto: m.texto, cargo: m.cargo, ts: m.ts ?? Date.now() });
    }
  } else if (tp === 'ranking' && (m.aba === 'elo' || m.aba === 'poder')) {
    const top = limpa(m.linhas ?? []).slice(0, 50);
    amostra('ranking_' + m.aba, { ...limpa(m), linhas: top.slice(0, 3) });
    dado(m.aba === 'elo' ? 'pvp_top' : 'poder_top', top);
    if (m.aba === 'elo') { pvpFila = top.map((l) => l.nick).filter(Boolean); agendarPerfis(); }
  } else if (tp === 'perfil') {
    amostra('perfil', limpa(m));
    dado('pvp_perfil', limpa(m.perfil ?? m));
  }
}
ipc.on('cmd', (_e, c) => {
  if (!souColeta()) return;
  if (c === 'pvp') pedirPvp();
  else if (c?.perfil) mandar({ t: 'ranking.perfil', nick: c.perfil });   // nível do treinador que pegou um shiny
});
window.addEventListener('wheel', (e) => { if (e.ctrlKey) { e.preventDefault(); ipc.send('zoom', e.deltaY < 0 ? 0.1 : -0.1); } }, { passive: false });
setInterval(() => {   // tempo ativo por campo + envio dos acumulados
  if (Date.now() - ultimaAtiv < 120000) cel(mapaAtual).segundos += 15;
}, 15000);
setInterval(() => {
  for (const [mapa, d] of Object.entries(porMapa)) {
    if (d.segundos || d.abates || d.capturas || d.fugas) emit({ tipo: 'hunt', mapa, d: { ...d } });
    delete porMapa[mapa];
  }
}, 30000);
setInterval(() => { const c = coletaCfg(); if (souColeta() && Date.now() - ultimoPvp > c.pvpMinutos * 60000 && jogo) pedirPvp(); }, 60000);
setTimeout(tick, 15000);

// ---- catálogos do jogo (nomes dos itens, espécies, chance de captura, preço NPC) ----
const prim = (o) => Object.fromEntries(Object.entries(o ?? {}).filter(([, v]) => v == null || ['string', 'number', 'boolean'].includes(typeof v)));
let catalogoOk = false, itensCatalogo = [], rotPedra = 0;
async function baixarCatalogos() {
  if (catalogoOk || !souColeta()) return;
  try {
    const pegar = async (u) => { const r = await fetch(u); return r.ok ? r.json() : null; };
    const lista = (j) => (Array.isArray(j) ? j : j?.items ?? j?.creatures ?? Object.values(j ?? {}).find(Array.isArray) ?? []);
    const itens = lista(await pegar('/assets/items.json')).map(prim);
    const especies = [];
    for (const u of ['/assets/creatures.json', '/assets/creatures-novos.json', '/assets/creatures-outland-novos.json']) {
      for (const c of lista(await pegar(u))) especies.push({ ...prim(c), loot: (c.loot ?? []).map((l) => l.name) });
    }
    itensCatalogo = itens;
    if (itens.length || especies.length) { dado('catalogo', { itens, especies }); catalogoOk = true; }
  } catch (e) { emit({ texto: 'catálogo: ' + e.message }); }
}
setInterval(baixarCatalogos, 20000);
let ultMouse = 0;
window.addEventListener('mousemove', (e) => {   // posição do cursor para o auto clicker
  if (Date.now() - ultMouse > 80) { ultMouse = Date.now(); ipc.send('mouse', conta, e.clientX, e.clientY); }
}, true);

// ---- preço-piso por item (base da análise de comprar na baixa / vender na alta) ----
function amostrarPiso(m) {
  if (m.aba !== 'item' || m.itemId == null || (m.moeda && m.moeda !== 'gold')) return;
  const ls = (m.linhas ?? []).filter((a) => Number(a.preco) > 0);
  if (!ls.length) return;
  dado('piso', { itemId: m.itemId, piso: Math.min(...ls.map((a) => Number(a.preco))), n: ls.length, qtd: ls.reduce((s, a) => s + (Number(a.qtd) || 1), 0), ts: Date.now() });
}
// A conta de coleta consulta devagar as pedras (uma a cada 20 s) para formar o histórico de preços.
setInterval(() => {
  const c = cfgAtual();
  if (!souColeta() || c.mercado?.acompanhar === false) return;
  // As 18 pedras de evolução do jogo (pedras-evolucao.mjs), sem "Shiny Stone" e afins.
  const PEDRAS = /^(sun|fire|water|leaf|thunder|ice|punch|venom|earth|feather|enigma|cocoon|rock|darkness|ancient|metal|heart|crystal) stone$/i;
  const ids = itensCatalogo.filter((i) => PEDRAS.test(String(i.nome ?? i.name ?? '').trim())).map((i) => i.id);
  if (ids.length) mandar({ t: 'market.item', itemId: ids[rotPedra++ % ids.length], moeda: 'gold' });
}, 20000);
// ---- esconde os cards de "fulano capturou um shiny" que o jogo desenha na tela (a lista fica no painel) ----
const cssBot = document.createElement('style');
const aplicarCss = () => {
  const ocultar = cfgAtual().coleta?.ocultarCards ?? true;
  cssBot.textContent = ocultar ? '#shiny-anuncio{display:none !important}' : '';
};
window.addEventListener('DOMContentLoaded', () => { document.head.appendChild(cssBot); aplicarCss(); });
setInterval(aplicarCss, 5000);
