// Auto clicker por conta, no estilo do "Speed Auto Clicker": intervalo + variação aleatória,
// botão esquerdo/direito, clique duplo, limite de cliques, clicar no cursor ou em ponto fixo.
// Clica por dentro da janela da conta (sendInputEvent), sem mexer no mouse real.
module.exports = function criarAutoClick({ view, zoom, cfg, salvar, estado }) {
  const st = {}, mouse = {};
  const conf = () => ({ intervaloMs: 400, aleatorio: 20, botao: 'left', modo: 'cursor', duplo: false, maxCliques: 0, pontos: {}, ...(cfg().autoclick ?? {}) });
  const pos = (n) => {
    const c = conf(), z = zoom(n) || 1;
    const p = c.modo === 'fixo' && c.pontos?.[n] ? c.pontos[n] : mouse[n];
    return p ? { x: Math.round(p.x * z), y: Math.round(p.y * z) } : null;   // px da página -> px da janela
  };
  function clicar(n) {
    const v = view(n), p = pos(n);
    if (!v || !p) return false;
    const wc = v.webContents, b = conf().botao === 'right' ? 'right' : 'left';
    const par = (cc, atraso) => {
      setTimeout(() => wc.sendInputEvent({ type: 'mouseDown', x: p.x, y: p.y, button: b, clickCount: cc }), atraso);
      setTimeout(() => wc.sendInputEvent({ type: 'mouseUp', x: p.x, y: p.y, button: b, clickCount: cc }), atraso + 25 + Math.random() * 35);
    };
    wc.sendInputEvent({ type: 'mouseMove', x: p.x, y: p.y });
    par(1, 0);
    if (conf().duplo) par(2, 90);
    return true;
  }
  function laco(n) {
    const s = st[n];
    if (!s?.ativo) return;
    const c = conf();
    if (clicar(n)) { s.cliques++; s.aviso = ''; } else s.aviso = 'passe o mouse sobre o jogo (ou fixe um ponto)';
    if (c.maxCliques > 0 && s.cliques >= c.maxCliques) return parar(n);
    const base = Math.max(50, c.intervaloMs), j = base * (c.aleatorio / 100) * (Math.random() * 2 - 1);
    s.timer = setTimeout(() => laco(n), Math.max(50, base + j));
    if (s.cliques % 5 === 0) estado();
  }
  function ligar(n) { if (st[n]?.ativo) return; st[n] = { ativo: true, cliques: 0, aviso: '' }; laco(n); estado(); }
  function parar(n) { const s = st[n]; if (!s) return; s.ativo = false; clearTimeout(s.timer); estado(); }
  return {
    alternar: (n) => (st[n]?.ativo ? parar(n) : ligar(n)),
    mouse: (n, x, y) => { mouse[n] = { x, y }; },
    marcarPonto(n) {
      if (!mouse[n]) return;
      salvar((c) => { c.autoclick = { ...conf(), modo: 'fixo', pontos: { ...conf().pontos, [n]: { x: Math.round(mouse[n].x), y: Math.round(mouse[n].y) } } }; });
      estado();
    },
    estadoAtual: () => Object.fromEntries(Object.entries(st).map(([n, s]) => [n, { ativo: s.ativo, cliques: s.cliques, aviso: s.aviso }])),
    pararTodos: () => Object.keys(st).forEach(parar),
  };
};
