const { app, BaseWindow, BrowserWindow, WebContentsView, Menu, ipcMain, Notification, screen, session } = require('electron');
const fs = require('fs'), path = require('path');
const { relatorio } = require('./analise');
const criarAutoClick = require('./autoclick');
let ac;
const cfgPath = path.join(__dirname, 'config.json');
const lerCfg = () => JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
let cfg = lerCfg();

// Opcional: "escalaGlobal": 0.8 no config.json reduz a resolução de TUDO (inclusive os menus).
if (cfg.escalaGlobal) app.commandLine.appendSwitch('force-device-scale-factor', String(cfg.escalaGlobal));
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=512');

const dados = () => app.getPath('userData');
const shinyFile = () => path.join(dados(), 'shinies.jsonl');
const vistos = new Set();
let win, barra, painel, jogos = [], modo = 'grade', painelAberto = true;
const TOPO = 44;

function carregarShinies() {
  try {
    for (const l of fs.readFileSync(shinyFile(), 'utf8').split('\n').filter(Boolean)) {
      const r = JSON.parse(l); vistos.add(`${r.conta}|${r.id}`);
    }
  } catch {}
}
const log = (txt) => painel?.webContents.send('log', `${new Date().toLocaleTimeString()} ${txt}`);

// ---- layout: grade 2x2 ou uma conta em tela cheia, painel dos bots na lateral ----
function layout() {
  if (!win) return;
  cfg = lerCfg();
  const [W, H] = win.getContentSize();
  const pw = painelAberto ? (cfg.painelLargura ?? 420) : 0;
  const area = { x: 0, y: TOPO, width: Math.max(200, W - pw), height: H - TOPO };
  barra.setBounds({ x: 0, y: 0, width: W, height: TOPO });
  painel.setBounds({ x: W - pw, y: TOPO, width: pw, height: H - TOPO });
  painel.setVisible(painelAberto);
  jogos.forEach((v, idx) => {
    const n = idx + 1;
    let b = null, z;
    if (modo === 'grade') {
      const w = Math.floor(area.width / 2), h = Math.floor(area.height / 2);
      b = { x: (idx % 2) * w, y: TOPO + Math.floor(idx / 2) * h, width: w, height: h };
      z = cfg.zoomGrade ?? 0.75;
    } else if (modo === n) { b = area; z = cfg.zoomFoco ?? 1; }
    if (b) {
      v.setBounds(b); v.setVisible(true);
      if (v._z !== z) { v.webContents.setZoomFactor(z); v._z = z; }
    } else v.setVisible(false);   // oculta: o Chromium reduz o uso de CPU dela
  });
}
const estado = () => barra?.webContents.send('estado', { modo, painelAberto });
const mudar = (m) => { modo = m; layout(); estado(); };

function ajustarZoom(d) {
  cfg = lerCfg();
  const chave = modo === 'grade' ? 'zoomGrade' : 'zoomFoco', padrao = modo === 'grade' ? 0.75 : 1;
  cfg[chave] = d === 'reset' ? padrao : Math.min(2.5, Math.max(0.3, +((cfg[chave] ?? padrao) + d).toFixed(2)));
  fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2));
  layout();
}
ipcMain.on('zoom', (_e, d) => ajustarZoom(d));

// ---- coleta: arquivos de dados e acumuladores ----
const anexar = (f, o) => fs.appendFileSync(path.join(dados(), f), JSON.stringify(o) + '\n');
const gravar = (f, o) => fs.writeFileSync(path.join(dados(), f), JSON.stringify(o));
const dedup = new Set(), idsMercado = new Set();
const lerJ = (f, def) => { try { return JSON.parse(fs.readFileSync(path.join(dados(), f), 'utf8')); } catch { return def; } };
let huntTotal = null, sessao = null, salvarTimer = null;
const somar = (a, b) => {
  for (const k of ['segundos', 'abates', 'xp', 'ouro', 'capturas', 'fugas', 'shinies']) a[k] = (a[k] || 0) + (b[k] || 0);
  a.drops ??= {};
  for (const [n, q] of Object.entries(b.drops || {})) a.drops[n] = (a.drops[n] || 0) + q;
  a.esp ??= {};
  for (const [n, e] of Object.entries(b.esp || {})) {
    const x = (a.esp[n] ??= { ab: 0, cap: 0, fug: 0, bolas: 0, ok: 0 });
    for (const k of Object.keys(x)) x[k] += e[k] || 0;
  }
};
const serie = {};   // conta -> últimas 20 janelas de ~30 s (cerca de 10 min)
let memoria = null;
function aoHunt(ev) {
  huntTotal ??= lerJ('hunt_stats.json', {}).total ?? {};
  sessao ??= { inicio: Date.now(), porConta: {} };
  somar((huntTotal[ev.mapa] ??= {}), ev.d);
  somar(((sessao.porConta[ev.conta] ??= {})[ev.mapa] ??= {}), ev.d);
  // Meta de abates/h: se nos últimos ~10 min neste campo a taxa passou do limite, memoriza os pokémons abatidos.
  const buf = (serie[ev.conta] ??= []);
  buf.push({ mapa: ev.mapa, seg: ev.d.segundos || 0, ab: ev.d.abates || 0, esp: ev.d.esp || {} });
  if (buf.length > 20) buf.shift();
  const mesmo = buf.filter((b) => b.mapa === ev.mapa);
  const seg = mesmo.reduce((a, b) => a + b.seg, 0), ab = mesmo.reduce((a, b) => a + b.ab, 0);
  const limite = lerCfg().metas?.abatesHora ?? 1600;
  if (seg >= 300 && (ab * 3600) / seg >= limite) {
    memoria ??= lerJ('memoria_1600.json', { limite, especies: {} });
    const taxa = Math.round((ab * 3600) / seg);
    const nomes = new Set(mesmo.flatMap((b) => Object.entries(b.esp).filter(([, e]) => e.ab > 0).map(([n]) => n)));
    for (const n of nomes) {
      const r = (memoria.especies[n] ??= { melhorTaxa: 0, mapa: ev.mapa, quando: 0 });
      if (!r.quando) log(`🧠 memorizado: ${n} em ${ev.mapa} (${taxa} abates/h)`);
      if (taxa >= r.melhorTaxa) { r.melhorTaxa = taxa; r.mapa = ev.mapa; }
      r.quando = Date.now();
    }
    memoria.limite = limite;
  }
  clearTimeout(salvarTimer);
  salvarTimer = setTimeout(() => { gravar('hunt_stats.json', { total: huntTotal, sessao }); if (memoria) gravar('memoria_1600.json', memoria); }, 5000);
}
const nomesItens = () => Object.fromEntries((lerJ('catalogo_itens.json', [])).map((i) => [i.id, i.nome ?? i.name]));
// ---- lives da Kick/Twitch: janela pequena, muda (a aba, não o player), sem imagens, login por conta ----
const lives = new Map(), liveWC = new Set(), sessoesFiltradas = new Set();
let liveSeq = 0;
// User-agent de Chrome normal: Kick/Twitch (Cloudflare, Google) costumam travar o login em navegadores com "Electron" no UA.
const UA = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${process.versions.chrome} Safari/537.36`;
function tipoLive(url) {
  try {
    const u = new URL(url), h = u.hostname.replace(/^www\./, '');
    const plat = h === 'kick.com' || h === 'player.kick.com' ? 'kick' : h === 'twitch.tv' || h === 'player.twitch.tv' ? 'twitch' : null;
    if (!plat) return null;
    if (h.startsWith('player.')) return plat;
    const seg = (u.pathname.split('/').filter(Boolean)[0] || '').toLowerCase();
    return seg && !['login', 'signup', 'oauth', 'oauth2', 'auth', 'settings', 'directory', 'videos', 'search', 'downloads', 'p'].includes(seg) ? plat : null;
  } catch { return null; }
}
const slugDe = (url) => { try { return new URL(url).pathname.split('/').filter(Boolean)[0] || ''; } catch { return ''; } };
function filtrarPesos(ses) {
  if (sessoesFiltradas.has(ses)) return;
  sessoesFiltradas.add(ses);
  ses.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (d, cb) => cb({ cancel: liveWC.has(d.webContentsId) && (d.resourceType === 'image' || d.resourceType === 'font') }));
}
const enviarLives = () => painel?.webContents.send('lives', [...lives.values()].map(({ id, conta, plat, grande, zoom }) => ({ id, conta, plat, grande, zoom })));
async function esquecerPlataforma(conta, plat) {
  const ses = session.fromPartition(`persist:conta${conta}-${plat}`);
  await ses.clearStorageData(); await ses.clearCache(); await ses.clearAuthCache();
}
function zoomLive(id, d) {
  const L = lives.get(id);
  if (!L || L.win.isDestroyed()) return;
  L.zoom = d === 'reset' ? (lerCfg().lives?.zoom ?? 0.5) : Math.min(3, Math.max(0.25, +(L.zoom + d).toFixed(2)));
  L.win.webContents.setZoomFactor(L.zoom);
  enviarLives();
}
// Destino "celular": o PC não abre a live; guarda o link (com QR no painel) para você abrir no telefone.
const paraCelular = [];
function enviarParaCelular(conta, plat, url) {
  if (paraCelular.some((x) => x.conta === conta && x.url === url)) return;
  paraCelular.unshift({ conta, plat, url, ts: Date.now() });
  paraCelular.length = Math.min(paraCelular.length, 20);
  painel?.webContents.send('celular', paraCelular);
  log(`📱 live ${plat} da conta ${conta} pronta para abrir no celular (veja em Lives)`);
}
ipcMain.on('celular.get', (e) => { e.returnValue = paraCelular; });
ipcMain.on('celular.limpar', () => { paraCelular.length = 0; painel?.webContents.send('celular', paraCelular); });
function abrirLive(conta, plat, url) {
  if (lerCfg().lives?.destino === 'celular') return enviarParaCelular(conta, plat, url);
  const l = lerCfg().lives ?? {}, tam = l.tamanho ?? { w: 360, h: 210 };
  const wa = screen.getPrimaryDisplay().workArea, k = lives.size % 4;
  const slug = slugDe(url);
  // Experimental: só o player da Kick (sem chat, menus e recomendações). Para resgatar pontos, "Ampliar" volta ao site completo.
  const leve = plat === 'kick' && l.kickPlayerLeve === true && !!slug && !url.includes('player.kick.com');
  const urlLeve = leve ? `https://player.kick.com/${slug}` : url;
  const win = new BrowserWindow({
    width: tam.w, height: tam.h, x: wa.x + wa.width - tam.w - 10, y: Math.max(wa.y, wa.y + wa.height - (tam.h + 10) * (k + 1)),
    title: `${plat} — conta ${conta}`, autoHideMenuBar: true,
    webPreferences: {
      partition: `persist:conta${conta}-${plat}`,   // perfil SÓ desta conta e desta plataforma: nada de cookies misturados
      preload: path.join(__dirname, 'live-preload.js'), contextIsolation: false, nodeIntegration: false, backgroundThrottling: false,
      additionalArguments: [`--plat=${plat}`, `--resgatar=${l.autoResgatarTwitch === false ? 0 : 1}`],
    },
  });
  const wc = win.webContents, wcId = wc.id, id = ++liveSeq;
  const L = { id, conta, plat, win, grande: false, zoom: l.zoom ?? 0.5, urlCompleta: url, urlLeve, leve, timer: null };
  lives.set(id, L);
  wc.setAudioMuted(true);   // muta a ABA, não o player
  liveWC.add(wcId); filtrarPesos(wc.session);
  wc.on('did-finish-load', () => wc.setZoomFactor(L.zoom));
  wc.on('before-input-event', (ev, inp) => {   // Ctrl + / Ctrl - / Ctrl 0 dentro da live
    if (inp.type !== 'keyDown' || !(inp.control || inp.meta)) return;
    const d = ['+', '=', 'Add'].includes(inp.key) ? 0.1 : ['-', '_', 'Subtract'].includes(inp.key) ? -0.1 : inp.key === '0' ? 'reset' : null;
    if (d !== null) { ev.preventDefault(); zoomLive(id, d); }
  });
  wc.on('zoom-changed', (_e, dir) => zoomLive(id, dir === 'in' ? 0.1 : -0.1));   // Ctrl + rodinha
  wc.setWindowOpenHandler(() => ({ action: 'allow' }));
  if (l.fecharAposMin > 0) L.timer = setTimeout(() => { if (!win.isDestroyed()) win.close(); }, l.fecharAposMin * 60000);
  win.on('closed', () => {
    clearTimeout(L.timer); lives.delete(id); liveWC.delete(wcId); enviarLives();
    if (lerCfg().lives?.esquecerLogin) esquecerPlataforma(conta, plat).catch(() => {});   // relogar sempre
  });
  win.loadURL(urlLeve);
  enviarLives();
}
ipcMain.on('live.zoom', (_e, id, d) => zoomLive(id, d));
ipcMain.on('live.ampliar', (_e, id) => {
  const L = lives.get(id);
  if (!L || L.win.isDestroyed()) return;
  const l = lerCfg().lives ?? {}, tam = l.tamanho ?? { w: 360, h: 210 };
  L.grande = !L.grande;
  L.zoom = L.grande ? (l.zoomAmpliado ?? 1) : (l.zoom ?? 0.5);
  L.win.setSize(L.grande ? 1100 : tam.w, L.grande ? 700 : tam.h);
  if (L.leve) L.win.loadURL(L.grande ? L.urlCompleta : L.urlLeve);   // o resgate de pontos precisa do site completo
  else L.win.webContents.setZoomFactor(L.zoom);
  if (L.grande) L.win.focus();
  enviarLives();
});
ipcMain.on('live.fechar', (_e, id) => { const L = lives.get(id); if (L && !L.win.isDestroyed()) L.win.close(); });
// Janela GRANDE só para entrar na Kick/Twitch (digitar e ler direito). O login fica salvo no perfil da conta do jogo.
ipcMain.on('login.abrir', (_e, conta, plat) => {
  const win = new BrowserWindow({
    width: 980, height: 740, autoHideMenuBar: true, title: `Entrar na ${plat === 'kick' ? 'Kick' : 'Twitch'} — conta ${conta} (feche ao terminar)`,
    webPreferences: { partition: `persist:conta${conta}-${plat}`, contextIsolation: true, nodeIntegration: false },
  });
  win.webContents.setWindowOpenHandler(() => ({ action: 'allow' }));
  win.loadURL(plat === 'kick' ? 'https://kick.com/' : 'https://www.twitch.tv/login');
});
// "Sair": apaga os logins de uma plataforma (kick/twitch) dessa conta, ou os logins externos usados no vínculo dentro do jogo.
ipcMain.on('login.limpar', async (_e, conta, alvo) => {
  try {
    if (alvo === 'kick' || alvo === 'twitch') {
      for (const L of [...lives.values()]) if (L.conta === conta && L.plat === alvo && !L.win.isDestroyed()) L.win.close();
      await esquecerPlataforma(conta, alvo);
      log(`🧹 conta ${conta}: login da ${alvo === 'kick' ? 'Kick' : 'Twitch'} apagado. Use "Entrar" para escolher a conta de novo.`);
      return;
    }
    const ses = session.fromPartition(`persist:conta${conta}`);   // perfil da janela do jogo (usado nos botões "vincular")
    let n = 0;
    for (const c of await ses.cookies.get({})) {
      const dom = c.domain.replace(/^\./, '');
      if (dom.endsWith('pokeidle.io')) continue;
      await ses.cookies.remove(`http${c.secure ? 's' : ''}://${dom}${c.path}`, c.name); n++;
    }
    await ses.clearStorageData({ origins: ['https://kick.com', 'https://www.kick.com', 'https://id.kick.com', 'https://twitch.tv', 'https://www.twitch.tv',
      'https://id.twitch.tv', 'https://accounts.google.com', 'https://www.google.com', 'https://appleid.apple.com', 'https://www.facebook.com', 'https://discord.com'] });
    await ses.clearCache(); await ses.clearAuthCache();
    log(`🧹 conta ${conta}: logins externos da janela do jogo apagados (${n} cookies); o login do jogo foi mantido.`);
  } catch (e) { log(`erro ao limpar logins: ${e.message}`); }
});
ipcMain.on('shiny.lista', (e) => {
  try { e.returnValue = fs.readFileSync(path.join(dados(), 'shiny_global.jsonl'), 'utf8').split('\n').filter(Boolean).slice(-100).map((l) => JSON.parse(l)); }
  catch { e.returnValue = []; }
});
// Nota do pokémon = a conta do próprio jogo (vendor/nota-pokemon.mjs), com os stats-base do catálogo.
let notaLib = null, especiesMapa = new Map(), especiesNome = new Map();
import(require('url').pathToFileURL(path.join(__dirname, 'vendor', 'nota-pokemon.mjs')).href).then((x) => { notaLib = x; }).catch((e) => console.error('nota:', e.message));
function recarregarEspecies() {
  const l = lerJ('catalogo_especies.json', []);
  especiesMapa = new Map(l.map((e) => [e.pokeId, e])); especiesNome = new Map(l.map((e) => [e.name, e]));
}
ipcMain.on('nota', (e, ficha) => {
  try {
    const esp = especiesMapa.get(ficha?.speciesId) ?? especiesNome.get(ficha?.nome) ?? null;
    e.returnValue = notaLib && esp ? notaLib.notaDePokemon(ficha, esp) : null;
  } catch { e.returnValue = null; }
});
const perfilVisto = new Set(), filaPerfil = [], ultimoPiso = new Map();
ipcMain.on('catalogo.itens', (e) => { e.returnValue = nomesItens(); });
ipcMain.on('ac.toggle', (_e, n) => ac?.alternar(n));
ipcMain.on('ac.ponto', (_e, n) => ac?.marcarPonto(n));
ipcMain.on('mouse', (_e, n, x, y) => ac?.mouse(n, x, y));
function aoDado(ev) {
  const d = ev.d;
  if (ev.canal === 'shiny') {
    const k = `${d.nick}|${d.p?.nome ?? d.texto ?? ''}|${Math.floor(d.ts / 60000)}`;
    if (dedup.has(k)) return; dedup.add(k);
    anexar('shiny_global.jsonl', d);
    painel?.webContents.send('shiny.global', d);   // vai para a lista do painel (sem spam no log)
    if (d.nick && !perfilVisto.has(d.nick) && !filaPerfil.includes(d.nick) && (lerCfg().coleta?.perfisShiny ?? true)) filaPerfil.push(d.nick);
  } else if (ev.canal === 'mercado') {
    for (const x of d) { if (x.id == null || idsMercado.has(x.id)) continue; idsMercado.add(x.id); anexar('mercado.jsonl', x); }
  } else if (ev.canal === 'chat') anexar('chat.jsonl', d);
  else if (ev.canal === 'dropLendario') anexar('drops_lendarios.jsonl', d);
  else if (ev.canal === 'pvp_top') { gravar('pvp_top.json', d); log(`🏆 PvP: ranking elo atualizado (${d.length}); lendo perfis...`); }
  else if (ev.canal === 'poder_top') gravar('poder_top.json', d);
  else if (ev.canal === 'captura_cfg') gravar('captura_cfg.json', d);
  else if (ev.canal === 'catalogo') {
    gravar('catalogo_itens.json', d.itens); gravar('catalogo_especies.json', d.especies);
    recarregarEspecies();
    painel?.webContents.send('catalogo', nomesItens());
    log(`📚 catálogo do jogo: ${d.itens.length} itens, ${d.especies.length} espécies`);
  }
  else if (ev.canal === 'pvp_perfil') { if (d?.nick) perfilVisto.add(d.nick); anexar('pvp_perfis.jsonl', d); }
  else if (ev.canal === 'piso') {
    const u = ultimoPiso.get(d.itemId) ?? 0;
    if (d.ts - u < 300000) return;   // no máximo uma amostra a cada 5 min por item
    ultimoPiso.set(d.itemId, d.ts); anexar('piso.jsonl', d);
  }
}
ipcMain.handle('analise', (_e, tipo) => relatorio(tipo, dados(), lerCfg()));
ipcMain.on('pvp.agora', () => {
  const c = { conta: 1, ...(lerCfg().coleta ?? {}) };
  jogos[(c.conta || 1) - 1]?.webContents.send('cmd', 'pvp');
});

ipcMain.on('modo', (_e, m) => mudar(m === 'grade' ? 'grade' : Number(m)));
ipcMain.on('painel.toggle', () => { painelAberto = !painelAberto; layout(); estado(); });
ipcMain.on('toggle', (_e, n) => mudar(modo === 'grade' ? n : 'grade'));

ipcMain.on('cfg', (e) => { cfg = lerCfg(); e.returnValue = cfg; });
ipcMain.on('cfg.set', (_e, patch) => {
  cfg = lerCfg();
  for (const [k, v] of Object.entries(patch)) cfg[k] = { ...cfg[k], ...v };
  fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2));
});
ipcMain.on('itens.get', (e) => {
  try { e.returnValue = JSON.parse(fs.readFileSync(path.join(dados(), 'itens_vistos.json'), 'utf8')); }
  catch { e.returnValue = {}; }
});
ipcMain.on('shiny.count', (e) => { e.returnValue = vistos.size; });
ipcMain.on('evt', (_e, ev) => {
  if (ev.tipo === 'shiny') {
    const k = `${ev.conta}|${ev.id}`;
    if (vistos.has(k)) return;
    vistos.add(k);
    fs.appendFileSync(shinyFile(), JSON.stringify({ ...ev, em: new Date().toISOString() }) + '\n');
    painel?.webContents.send('shiny', ev);
    log(`✨ [conta ${ev.conta}] shiny: ${ev.nome} nv${ev.nivel ?? '?'}`);
  } else if (ev.tipo === 'alerta') {
    new Notification({ title: 'Poke Idle — oferta', body: ev.texto }).show();
    log(`🔔 [conta ${ev.conta}] ${ev.texto}`);
  } else if (ev.tipo === 'itens') {
    fs.writeFileSync(path.join(dados(), 'itens_vistos.json'), JSON.stringify(ev.resumo, null, 2));
    painel?.webContents.send('itens', ev.resumo);
    log(`📋 catálogo de itens salvo (${Object.keys(ev.resumo).length} itens)`);
  } else if (ev.tipo === 'dado') aoDado(ev);
  else if (ev.tipo === 'hunt') aoHunt(ev);
  else if (ev.tipo === 'stat') painel?.webContents.send('stat', ev);
  else if (ev.tipo === 'amostra') {
    fs.writeFileSync(path.join(dados(), `amostra_${ev.aba}.json`), JSON.stringify(ev.amostra, null, 2));
    log(`📄 amostra salva: amostra_${ev.aba}.json`);
  } else log(`[conta ${ev.conta}] ${ev.texto}`);
});

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  for (let i = 1; i <= 4; i++) for (const suf of ['', '-kick', '-twitch']) session.fromPartition(`persist:conta${i}${suf}`).setUserAgent(UA);
  carregarShinies();
  recarregarEspecies();
  for (const x of (() => { try { return fs.readFileSync(path.join(dados(), 'mercado.jsonl'), 'utf8').split('\n').filter(Boolean); } catch { return []; } })()) { try { idsMercado.add(JSON.parse(x).id); } catch {} }
  win = new BaseWindow({ width: 1600, height: 900, title: 'Poke Idle — multi-conta' });
  const UI = { nodeIntegration: true, contextIsolation: false };
  barra = new WebContentsView({ webPreferences: UI });
  painel = new WebContentsView({ webPreferences: UI });
  barra.webContents.loadFile('barra.html');
  painel.webContents.loadFile('painel.html');
  barra.webContents.on('did-finish-load', estado);
  painel.webContents.on('did-finish-load', () => log(`Dados em: ${dados()}`));
  win.contentView.addChildView(barra);
  win.contentView.addChildView(painel);
  for (let i = 1; i <= 4; i++) {
    const v = new WebContentsView({
      webPreferences: {
        partition: `persist:conta${i}`,        // login/sessão isolados por conta
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: false,               // o preload precisa trocar o WebSocket antes do jogo
        nodeIntegration: false,
        backgroundThrottling: true,
        additionalArguments: [`--conta=${i}`],
      },
    });
    v.webContents.on('did-finish-load', () => { v._z = null; layout(); });
    const conta = i;
    v.webContents.on('before-input-event', (ev, inp) => {
      if (inp.type !== 'keyDown') return;
      if (inp.key === 'F6') { ev.preventDefault(); ac?.alternar(conta); return; }   // liga/desliga o auto clicker
      if (inp.key === 'F7') { ev.preventDefault(); ac?.marcarPonto(conta); return; } // fixa o ponto de clique
      if (!(inp.control || inp.meta)) return;
      const k = inp.key;
      const d = k === '+' || k === '=' || k === 'Add' ? 0.1 : k === '-' || k === '_' || k === 'Subtract' ? -0.1 : k === '0' ? 'reset' : null;
      if (d !== null) { ev.preventDefault(); ajustarZoom(d); }
    });
    v.webContents.setWindowOpenHandler(({ url }) => {
      const plat = tipoLive(url);
      if (plat) { abrirLive(conta, plat, url); return { action: 'deny' }; }
      return { action: 'allow', overrideBrowserWindowOptions: { width: 560, height: 720, autoHideMenuBar: true } };   // OAuth/pagamento continuam funcionando
    });
    v.webContents.on('will-navigate', (e, url) => { const plat = tipoLive(url); if (plat) { e.preventDefault(); abrirLive(conta, plat, url); } });
    v.webContents.loadURL(cfg.url);
    win.contentView.addChildView(v);
    jogos.push(v);
  }
  ac = criarAutoClick({
    view: (n) => jogos[n - 1], zoom: (n) => jogos[n - 1]?._z || 1, cfg: lerCfg,
    salvar: (fn) => { cfg = lerCfg(); fn(cfg); fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2)); },
    estado: () => painel?.webContents.send('ac.estado', ac.estadoAtual()),
  });
  for (const x of (() => { try { return fs.readFileSync(path.join(dados(), 'pvp_perfis.jsonl'), 'utf8').split('\n').filter(Boolean); } catch { return []; } })()) { try { perfilVisto.add(JSON.parse(x).nick); } catch {} }
  setInterval(() => {   // um perfil a cada 6 s: pega o nível de quem capturou shiny
    const nick = filaPerfil.shift();
    if (nick) jogos[((lerCfg().coleta?.conta) || 1) - 1]?.webContents.send('cmd', { perfil: nick });
  }, 6000);
  win.on('resize', layout);
  win.on('closed', () => app.quit());
  win.maximize();
  layout();
});
