// Roda dentro das janelas de live (Kick/Twitch) abertas pelo cliente.
const plat = ((process.argv.find((a) => a.startsWith('--plat=')) || '').split('=')[1]) || '';
const resgatar = ((process.argv.find((a) => a.startsWith('--resgatar=')) || '').split('=')[1]) !== '0';
try {
  // Qualidade mínima na Twitch (160p): o player lê essa chave ao iniciar. Menos vídeo = menos RAM e rede.
  if (location.hostname.endsWith('twitch.tv')) localStorage.setItem('video-quality', JSON.stringify({ default: '160p30' }));
} catch {}
// Baú de pontos da Twitch: clica sozinho no "Claim Bonus". (Na Kick o resgate de recompensas é manual:
// use "Ampliar" no painel, escolha a recompensa e depois "Reduzir".)
if (plat === 'twitch' && resgatar) {
  setInterval(() => { try { document.querySelector('.claimable-bonus__icon')?.click(); } catch {} }, 15000);
}
