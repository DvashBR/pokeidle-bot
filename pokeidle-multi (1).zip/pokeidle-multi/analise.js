// Relatórios em texto, calculados a partir dos arquivos que a coleta grava.
const fs = require('fs'), path = require('path');
const ler = (d, f) => { try { return fs.readFileSync(path.join(d, f), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)); } catch { return []; } };
const lerJ = (d, f, def) => { try { return JSON.parse(fs.readFileSync(path.join(d, f), 'utf8')); } catch { return def; } };
const cont = (arr, fn) => { const c = {}; for (const x of arr) { const k = fn(x); if (k != null && k !== '') c[k] = (c[k] || 0) + 1; } return c; };
const topo = (c, n = 15) => Object.entries(c).sort((a, b) => b[1] - a[1]).slice(0, n);
const tab = (c, n, tot) => topo(c, n).map(([k, v]) => `  ${String(v).padStart(5)}${tot ? '  ' + (100 * v / tot).toFixed(1).padStart(5) + '%' : ''}  ${k}`).join('\n') || '  (sem dados)';
const fmt = (n) => Math.round(n || 0).toLocaleString('pt-BR');
const quant = (a, q) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.min(s.length - 1, Math.floor(q * s.length))] : null; };
const VALIOSO = /pedra|stone|token|mega|shiny|ticket|chave|key|bicicleta|bike|ovo|egg|fragmento|\btm\b/i;
const vazio = (txt) => txt + '\n(Ainda sem dados. Deixe as contas logadas jogando um tempo e peça de novo.)';

function shinies(d) {
  const r = ler(d, 'shiny_global.jsonl');
  if (!r.length) return vazio('SHINIES DO SERVIDOR');
  const nome = (x) => x.p?.nome ?? x.p?.name ?? x.texto ?? '?';
  const lv = (x) => Number(x.p?.level);
  const q = r.map((x) => Number(x.p?.quality)).filter(Number.isFinite);
  const faixa = (x) => (lv(x) >= 1 ? `nv ${Math.floor((lv(x) - 1) / 50) * 50 + 1}-${Math.floor((lv(x) - 1) / 50) * 50 + 50}` : null);
  const mapa = (x) => x.mapa ?? x.p?.mapa ?? x.p?.huntSlug ?? 'desconhecido (anúncio global não informa)';
  const n = r.length;
  return [`SHINIES DO SERVIDOR — ${n} registrados`,
    '\nPor pokémon (qtd, %):', tab(cont(r, nome), 15, n),
    '\nPor faixa de nível:', tab(cont(r, faixa), 12, n),
    '\nPor campo:', tab(cont(r, mapa), 12, n),
    '\nPor jogador:', tab(cont(r, (x) => x.nick), 10, n),
    '\nPor hora do dia:', tab(cont(r, (x) => String(new Date(x.ts).getHours()).padStart(2, '0') + 'h'), 24, n),
    '\nPor dia da semana:', tab(cont(r, (x) => ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'][new Date(x.ts).getDay()]), 7, n),
    '\nPor data:', tab(cont(r, (x) => new Date(x.ts).toLocaleDateString('pt-BR')), 10, n),
    (() => {
      const ts = r.map((x) => x.ts).sort((x, y) => x - y), horas = (ts[ts.length - 1] - ts[0]) / 3.6e6;
      const comuns = topo(cont(r, nome), 3).map(([k, v]) => `${k} (${v})`).join(', ');
      const unicos = Object.entries(cont(r, nome)).filter(([, v]) => v === 1).map(([k]) => k);
      return `\nRitmo: ${horas >= 0.5 ? (n / horas).toFixed(1) + ' shinies/h em ' + horas.toFixed(1) + ' h de coleta' : 'dados ainda curtos'}\nMais frequentes: ${comuns}\nVistos uma única vez (${unicos.length}): ${unicos.slice(0, 15).join(', ') || '-'}`;
    })(),
    (() => {   // nível do treinador, quando o perfil dele já foi lido
      const nivDe = (p) => Number(p.nivel ?? p.level ?? p.lvl ?? p.nv);
      const perf = Object.fromEntries(ler(d, 'pvp_perfis.jsonl').filter((p) => p.nick).map((p) => [p.nick, nivDe(p)]));
      const nv = r.map((x) => perf[x.nick]).filter(Number.isFinite);
      return nv.length ? `\nNível do treinador (${nv.length} perfis lidos): mediana ${fmt(quant(nv, .5))}, p25 ${fmt(quant(nv, .25))}, p75 ${fmt(quant(nv, .75))}, máx ${fmt(Math.max(...nv))}` : '\nNível do treinador: os perfis ainda estão sendo lidos (um a cada 6 s) ou o perfil não traz o campo.';
    })(),
    q.length ? `\nQualidade (n=${q.length}): mín ${fmt(quant(q, 0))} | p25 ${fmt(quant(q, .25))} | mediana ${fmt(quant(q, .5))} | p75 ${fmt(quant(q, .75))} | máx ${fmt(quant(q, 1))}` : '\nQualidade: o anúncio não trouxe o campo.',
  ].join('\n');
}

function hunt(d) {
  const s = lerJ(d, 'hunt_stats.json', null);
  if (!s) return vazio('PRODUTIVIDADE');
  const h = (v, seg) => (seg > 0 ? fmt((v * 3600) / seg) : '-');
  const somaMapas = (mapas) => Object.values(mapas).reduce((a, m) => { for (const k of ['segundos', 'abates', 'xp', 'ouro', 'capturas', 'shinies']) a[k] = (a[k] || 0) + (m[k] || 0); return a; }, {});
  const out = [`PRODUTIVIDADE — sessão iniciada ${new Date(s.sessao?.inicio ?? Date.now()).toLocaleTimeString()}`, ''];
  for (const [conta, mapas] of Object.entries(s.sessao?.porConta ?? {})) {
    const t = somaMapas(mapas);
    out.push(`Conta ${conta}: ${Math.round(t.segundos / 60)} min ativos | ${fmt(t.abates)} abates (${h(t.abates, t.segundos)}/h) | XP ${h(t.xp, t.segundos)}/h | ouro ${h(t.ouro, t.segundos)}/h | capturas ${t.capturas} | shinies ${t.shinies}`);
  }
  const todos = Object.entries(s.total ?? {}).filter(([, m]) => m.segundos >= 600);
  const melhor = (fn) => todos.map(([k, m]) => [k, fn(m)]).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]) => `  ${k}: ${fmt(v)}/h`).join('\n') || '  (precisa de ≥10 min por mapa)';
  const valiosos = (m) => Object.entries(m.drops ?? {}).filter(([n]) => VALIOSO.test(n)).reduce((a, [, q]) => a + q, 0) * 3600 / m.segundos;
  out.push('\nMelhores campos para grind (histórico, ≥10 min de dado):',
    'XP/h:', melhor((m) => (m.xp * 3600) / m.segundos),
    'Ouro/h:', melhor((m) => (m.ouro * 3600) / m.segundos),
    'Abates/h:', melhor((m) => (m.abates * 3600) / m.segundos),
    'Drops valiosos/h:', melhor(valiosos));
  return out.join('\n');
}

function mapas(d) {
  const s = lerJ(d, 'hunt_stats.json', null);
  if (!s) return vazio('CAMPOS E DROPS');
  const linhas = Object.entries(s.total ?? {}).filter(([, m]) => m.segundos >= 300 && m.abates > 0).map(([k, m]) => {
    const val = Object.entries(m.drops ?? {}).filter(([n]) => VALIOSO.test(n));
    const vph = (val.reduce((a, [, q]) => a + q, 0) * 3600) / m.segundos;
    const top = Object.entries(m.drops ?? {}).sort((a, b) => b[1] - a[1]).slice(0, 5)
      .map(([n, q]) => `${VALIOSO.test(n) ? '⭐' : ''}${n} ${(q * 3600 / m.segundos).toFixed(1)}/h`).join(', ');
    return { k, vph, txt: `${k}  (${Math.round(m.segundos / 60)} min, ${fmt(m.abates)} abates)\n   valiosos: ${vph.toFixed(1)}/h | ouro ${fmt(m.ouro * 3600 / m.segundos)}/h\n   drops: ${top || '-'}` };
  }).sort((a, b) => b.vph - a.vph);
  return 'CAMPOS × DROPS (ordenado por itens valiosos/h; ⭐ = pedra, token, mega, ticket...)\n\n' + (linhas.map((l) => l.txt).join('\n\n') || '(precisa de ≥5 min por campo)');
}

function mercado(d) {
  const r = ler(d, 'mercado.jsonl');
  if (!r.length) return vazio('MERCADO');
  const itens = lerJ(d, 'itens_vistos.json', {});
  const poke = r.filter((x) => x.nome && !x.itemId), it = r.filter((x) => x.itemId);
  const preco = (x) => (x.moeda === 'gold' ? Number(x.preco) : null);
  const porNome = {};
  for (const x of poke) (porNome[x.nome] ??= []).push(x);
  const l1 = Object.entries(porNome).sort((a, b) => b[1].length - a[1].length).slice(0, 20).map(([n, a]) => {
    const p = a.map(preco).filter(Number.isFinite);
    const notas = a.map((x) => x.nota).filter(Number.isFinite);
    return `  ${String(a.length).padStart(4)}x ${n}  | menor ${p.length ? fmt(Math.min(...p)) : '-'} | mediana ${p.length ? fmt(quant(p, .5)) : '-'} coins | nota média ${notas.length ? (notas.reduce((x, y) => x + y, 0) / notas.length).toFixed(2) : '-'}${a.some((x) => x.shiny) ? ' ✨' : ''}`;
  });
  const porItem = {};
  for (const x of it) (porItem[x.itemId] ??= []).push(x);
  const l2 = Object.entries(porItem).sort((a, b) => b[1].length - a[1].length).slice(0, 15).map(([id, a]) => {
    const p = a.map(preco).filter(Number.isFinite);
    const v = itens[id]; const nm = v?.nome ?? v?.name ?? a[0].item ?? id;
    return `  ${String(a.length).padStart(4)}x ${nm}  | menor ${p.length ? fmt(Math.min(...p)) : '-'} | mediana ${p.length ? fmt(quant(p, .5)) : '-'} coins`;
  });
  return [`MERCADO — ${r.length} anúncios únicos vistos (${poke.length} pokémon, ${it.length} itens)`,
    '\nPokémon que mais aparecem nas lojas:', l1.join('\n') || '  (nenhum)',
    '\nItens mais anunciados:', l2.join('\n') || '  (nenhum)'].join('\n');
}

function acharPokes(o, out = [], prof = 0) {
  if (!o || typeof o !== 'object' || prof > 6) return out;
  const nm = o.nome ?? o.especie ?? o.name;
  if (typeof nm === 'string' && (o.level != null || o.nivel != null)) out.push(o);
  for (const v of Object.values(o)) acharPokes(v, out, prof + 1);
  return out;
}

function pvp(d) {
  const top = lerJ(d, 'pvp_top.json', []), poder = lerJ(d, 'poder_top.json', []);
  if (!top.length && !poder.length) return vazio('PVP TOP 50');
  const nicks = new Set(top.map((l) => l.nick));
  const perfis = ler(d, 'pvp_perfis.jsonl').filter((p) => !nicks.size || nicks.has(p.nick));
  const nomeL = (l) => l.nome ?? l.especie ?? l.pokemon?.nome ?? (l.speciesId != null ? `#${l.speciesId}` : null);
  const uso = {};
  for (const l of poder) { const n = nomeL(l); if (n) uso[n] = (uso[n] || 0) + 1; }
  const dosPerfis = perfis.flatMap((p) => acharPokes(p));
  for (const p of dosPerfis) { const n = p.nome ?? p.especie ?? p.name; uso[n] = (uso[n] || 0) + 1; }
  const lvls = [...poder.map((l) => Number(l.level)), ...dosPerfis.map((p) => Number(p.level ?? p.nivel))].filter(Number.isFinite);
  const oferta = cont(ler(d, 'mercado.jsonl').filter((x) => x.nome), (x) => x.nome);
  const oport = Object.entries(uso).map(([n, u]) => [n, u, oferta[n] || 0]).sort((a, b) => b[1] / (1 + b[2]) - a[1] / (1 + a[2])).slice(0, 10)
    .map(([n, u, o]) => `  ${n}: usado ${u}x no topo, ${o} à venda`);
  const elos = top.map((l) => Number(l.valor)).filter(Number.isFinite);
  return [`PVP TOP ${top.length || '?'} — ${perfis.length} perfis lidos, ${poder.length} pokémon do ranking de poder`,
    elos.length ? `Elo: ${fmt(Math.max(...elos))} (1º) a ${fmt(Math.min(...elos))} (último)` : '',
    lvls.length ? `Nível dos pokémon do topo: mediana ${fmt(quant(lvls, .5))}, p25 ${fmt(quant(lvls, .25))}, máx ${fmt(Math.max(...lvls))}` : '',
    '\nPokémon mais usados pelo topo:', tab(uso, 15),
    '\nOportunidade (muito usado, pouca oferta nas lojas):', oport.join('\n') || '  (sem dados)',
    '\nCampos que o jogo expõe (para refinarmos a análise):',
    `  linha do ranking elo: ${Object.keys(top[0] ?? {}).join(', ') || '-'}`,
    `  linha do ranking poder: ${Object.keys(poder[0] ?? {}).join(', ') || '-'}`,
    `  perfil: ${Object.keys(perfis[0] ?? {}).join(', ') || '-'}`].filter((x) => x !== '').join('\n');
}

const PAL = [/\bdicas?\b/i, /\btip\b/i, /recomend/i, /vale a pena/i, /\bmelhor\b/i, /n[aã]o (compre|vendam?|gaste)/i, /\bevit(e|em|ar)\b/i, /cuidado/i, /\b(farm|hunt|spot|mapa|campo)\b/i, /\bxp\b/i, /drop/i, /pedra|stone/i, /\bboss\b/i, /\bpvp\b|ranked/i, /funciona|consegui/i];
const RUIM = [/\b(vendo|compro|troco|wts|wtb)\b/i, /^@/, /https?:\/\//i, /k{3,}|haha/i];
function dicas(d) {
  const r = ler(d, 'chat.jsonl');
  if (!r.length) return vazio('DICAS DO CHAT');
  const vistos = new Map();
  for (const m of r) {
    const t = String(m.texto ?? '').trim();
    if (t.length < 30) continue;
    let sc = PAL.filter((p) => p.test(t)).length + (t.length >= 60) + (t.length >= 100) - 3 * RUIM.filter((p) => p.test(t)).length - 2 * t.endsWith('?');
    if (sc < 3) continue;
    const k = t.toLowerCase().replace(/\W+/g, ' ');
    const e = vistos.get(k) ?? { ...m, sc, n: 0 }; e.n++; vistos.set(k, e);
  }
  const lista = [...vistos.values()].sort((a, b) => b.sc + b.n - (a.sc + a.n) || b.ts - a.ts).slice(0, 40);
  return `DICAS DO CHAT — ${lista.length} selecionadas de ${r.length} mensagens\n\n` +
    (lista.map((m) => `[${m.canal ?? '?'}] ${m.de}: ${m.texto}${m.n > 1 ? `  (repetida ${m.n}x)` : ''}`).join('\n\n') || '(nenhuma mensagem passou no filtro ainda)');
}


function somaObs(h) {
  const obs = {};
  for (const mp of Object.values(h.total ?? {})) for (const [n, e] of Object.entries(mp.esp ?? {})) {
    const o = (obs[n] ??= { ab: 0, cap: 0, fug: 0, bolas: 0, ok: 0 });
    for (const k of Object.keys(o)) o[k] += e[k] || 0;
  }
  return obs;
}
function pokedex(d) {
  const esp = lerJ(d, 'catalogo_especies.json', []);
  if (!esp.length) return vazio('POKÉDEX — o catálogo é baixado do jogo ~20 s depois do login da conta de coleta.');
  const itens = lerJ(d, 'catalogo_itens.json', []);
  const C = { base: 0.0075, piso: 0.003, teto: 0.1, raridadeDiv: 17, precoSemPreco: 6.5e9, ...(lerJ(d, 'captura_cfg.json', {}).captura ?? {}) };
  const bolas = itens.filter((i) => Number(i.catchRate) > 0 && Number(i.catchRate) < 255).sort((x, y) => x.catchRate - y.catchRate);
  const nb = (b) => b?.nome ?? b?.name ?? '?';
  const ref = bolas[0], top = bolas[bolas.length - 1];
  // Mesma conta do jogo (chanceDeCaptura), com o bicho de HP cheio.
  const chance = (e, cr) => {
    const preco = e.priceNpc > 0 ? e.priceNpc : C.precoSemPreco;
    const rar = Math.log10(Math.max(100, preco)) - 1;
    return Math.max(C.piso, Math.min(C.teto, C.base * (cr / (1 + rar ** 3 / (C.raridadeDiv ?? 17))) * 1.4));
  };
  const L = esp.filter((e) => e.name).map((e) => {
    const valor = Number(e.sellValue) > 0 ? Number(e.sellValue) : Number(e.priceNpc) || 0;
    const p = chance(e, ref?.catchRate ?? 1);
    return { n: e.name, p, pTop: chance(e, top?.catchRate ?? ref?.catchRate ?? 1), valor, vpb: p * valor, venda: e.priceNpc > 0, loot: e.loot ?? [] };
  });
  const f = (x) => (x * 100).toFixed(2) + '%';
  const lin = (arr, fn) => arr.map(fn).join('\n') || '  (nenhum)';
  const obs = somaObs(lerJ(d, 'hunt_stats.json', {}));
  const real = Object.entries(obs).filter(([, o]) => o.bolas >= 20).sort((x, y) => y[1].bolas - x[1].bolas).slice(0, 15);
  const teo = Object.fromEntries(L.map((x) => [x.n, x]));
  return [`POKÉDEX — ${L.length} espécies | bola de referência: ${nb(ref)} (×${ref?.catchRate ?? '?'}) | melhor bola: ${nb(top)} (×${top?.catchRate ?? '?'})`,
    '\nMais fáceis de capturar (com a bola de referência):',
    lin([...L].sort((x, y) => y.p - x.p || y.valor - x.valor).slice(0, 20), (x) => `  ${f(x.p)} (~${Math.ceil(1 / x.p)} bolas)  ${x.n}  | NPC ${fmt(x.valor)}`),
    '\nMais difíceis:', lin([...L].sort((x, y) => x.p - y.p).slice(0, 10), (x) => `  ${f(x.p)} (~${fmt(1 / x.p)} bolas, com a melhor bola ${f(x.pTop)})  ${x.n}`),
    '\nMelhor valor esperado por bola (chance × preço NPC):',
    lin(L.filter((x) => x.venda).sort((x, y) => y.vpb - x.vpb).slice(0, 20), (x) => `  ${fmt(x.vpb)}/bola  ${x.n}  (${f(x.p)}, NPC ${fmt(x.valor)})`),
    '\nMais valiosos para vender ao NPC:', lin([...L].sort((x, y) => y.valor - x.valor).slice(0, 12), (x) => `  ${fmt(x.valor)}  ${x.n}  (${f(x.p)})`),
    '\nDropam pedras (para farmar):',
    lin(L.filter((x) => x.loot.some((n) => /stone|pedra/i.test(n))).slice(0, 25), (x) => `  ${x.n}: ${x.loot.filter((n) => /stone|pedra/i.test(n)).join(', ')}`),
    '\nObservado por você (≥20 bolas) — real × teórico (bola de referência):',
    lin(real, ([n, o]) => `  ${n}: ${f(o.ok / o.bolas)} real em ${o.bolas} bolas | teórico ${teo[n] ? f(teo[n].p) : '?'} | ${o.cap} capturados, ${o.fug} fugiram`),
  ].join('\n');
}
function meta(d) {
  const m = lerJ(d, 'memoria_1600.json', null);
  const nomes = Object.keys(m?.especies ?? {});
  if (!nomes.length) return vazio('META DE ABATES/H — nenhum pokémon passou do limite ainda (padrão 1600/h, ajustável em config.json > metas.abatesHora; precisa de ≥5 min no campo).');
  const obs = somaObs(lerJ(d, 'hunt_stats.json', {}));
  return [`META: pokémons abatidos em campos com ≥ ${fmt(m.limite)} abates/h — ${nomes.length} memorizados`, '',
    ...nomes.sort((x, y) => m.especies[y].melhorTaxa - m.especies[x].melhorTaxa).map((n) => {
      const r = m.especies[n], o = obs[n];
      return `${n}: ${fmt(r.melhorTaxa)}/h em ${r.mapa}${o ? ` | capturas ${o.cap}, bolas ${o.bolas}${o.bolas ? ` (${(100 * o.ok / o.bolas).toFixed(1)}% de acerto)` : ''}` : ''}`;
    })].join('\n');
}


function arbitragem(d, cfg) {
  const r = ler(d, 'piso.jsonl');
  if (!r.length) return vazio('ARBITRAGEM — o bot acompanha as pedras (uma consulta a cada 20 s) e grava o menor preço de cada uma a cada 5 min.');
  const taxa = cfg?.mercado?.taxaVenda ?? 0.15, sobre = cfg?.mercado?.taxaSobre ?? 'venda', roiMin = cfg?.mercado?.roiMin ?? 0.05;
  const nomes = Object.fromEntries(lerJ(d, 'catalogo_itens.json', []).map((i) => [i.id, i.nome ?? i.name]));
  const novos = {};
  const lm = ler(d, 'mercado.jsonl').filter((x) => x.itemId != null);
  const tsM = lm.map((x) => x.ts);
  const horasM = tsM.length ? Math.max(1, (Math.max(...tsM) - Math.min(...tsM)) / 3.6e6) : 1;
  for (const x of lm) novos[x.itemId] = (novos[x.itemId] || 0) + 1;
  const por = {};
  for (const x of r) (por[x.itemId] ??= []).push(x);
  const liquido = (venda, compra) => (sobre === 'lucro' ? (venda - compra) * (1 - taxa) : venda * (1 - taxa) - compra);
  const linhas = Object.entries(por).filter(([, a]) => a.length >= 4).map(([id, a]) => {
    const p = a.map((x) => x.piso), compra = quant(p, .25), venda = quant(p, .75), atual = a[a.length - 1].piso;
    const horas = (a[a.length - 1].ts - a[0].ts) / 3.6e6, liq = liquido(venda, compra);
    const empate = sobre === 'lucro' ? compra : compra / (1 - taxa);
    const maxCompra = sobre === 'lucro' ? venda * (1 - taxa) / (roiMin + 1 - taxa) : venda * (1 - taxa) / (1 + roiMin);
    return { id, nome: nomes[id] ?? `item ${id}`, n: a.length, horas, compra, venda, atual, liq, roi: liq / compra, empate, maxCompra, agora: atual <= compra };
  }).sort((x, y) => y.roi - x.roi);
  const sel = (x) => (x.roi >= roiMin ? (x.n >= 20 && x.horas >= 3 ? '✅' : '⚠️') : '❌');
  return [`ARBITRAGEM — comprar na baixa (p25 do piso) e vender na alta (p75), taxa de ${(taxa * 100).toFixed(0)}% ${sobre === 'lucro' ? 'sobre o lucro' : 'sobre o valor da venda'}, ROI mínimo ${(roiMin * 100).toFixed(0)}%`,
    `Para empatar com taxa sobre a venda, o preço precisa subir ${(100 * (1 / (1 - taxa) - 1)).toFixed(1)}% entre a compra e a venda.`, '',
    ...linhas.map((x) => `${sel(x)} ${x.nome}: comprar ≤ ${fmt(x.compra)} | vender ≥ ${fmt(x.venda)} | líquido ${fmt(x.liq)}/un (ROI ${(x.roi * 100).toFixed(1)}%)\n     piso agora ${fmt(x.atual)}${x.agora ? '  ← NA BAIXA' : ''} | empate em ${fmt(x.empate)} | comprar até ${fmt(x.maxCompra)} para ${(roiMin * 100).toFixed(0)}% de ROI | ${x.n} amostras / ${x.horas.toFixed(1)} h | ${((novos[x.id] || 0) / horasM).toFixed(1)} anúncios novos/h`),
    '', 'Atenção: são preços ANUNCIADOS (o piso), não vendas fechadas; ✅ = ≥20 amostras e ≥3 h de dados. Use o "comprar até" como preço máximo na lista de compra.'].join('\n');
}

const R = { shinies, hunt, mapas, mercado, pvp, dicas, pokedex, meta, arbitragem };
module.exports = { relatorio: (tipo, d, cfg) => { try { return (R[tipo] ?? (() => 'relatório desconhecido'))(d, cfg); } catch (e) { return 'erro no relatório: ' + e.message; } } };
