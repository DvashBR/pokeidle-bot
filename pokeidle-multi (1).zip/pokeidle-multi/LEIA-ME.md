# Poke Idle — multi-conta

1. Instale o Node.js, abra um terminal nesta pasta e rode: `npm install` e depois `npm start`.
2. Abrem o Painel e 4 janelas (Conta 1..4). Faça login uma vez em cada; a sessão fica salva por conta.
3. **Resolução / RAM**: em `config.json` ajuste `escala` (0.5 a 1, reduz os pixels renderizados) e `zoom` (tamanho do jogo na janela).
4. **Shinies**: registrados sozinhos em `shinies.jsonl` (pasta de dados do app), sem duplicar.
5. **Alertas** (conta `alerta.conta`): abra o Market > Pokémon na tela, deixe o filtro/ordem que quiser (ex. mais baratos). O bot repete essa mesma busca a cada ~8 s e avisa se nota >= 3,8 e preço <= 40M coins ou <= 50 gemas.
6. **Compra de pedras** (só coins, nunca gemas): abra Market > Itens uma vez; o painel salva `itens_vistos.json` com os IDs. Coloque o `itemId` de cada pedra em `config.json` > `compra.pedras`, com `maxPreco`. Defina `gastoMaxSessao` e `maxCompras`, e marque "Compra automática" no painel.
7. Teste primeiro com limites baixos e confira no log se o pedido foi aceito.

## Layout (v2)
- Uma janela só: grade 2x2 com as 4 contas. O botão ⤢ no canto de cada tela (ou os botões "Conta N" da barra) maximiza uma; ⤢ de novo ou "Grade" volta.
- Botão "Bots" mostra/esconde o painel lateral. Nele você escolhe em qual conta rodam o alerta e a compra.
- Tamanho do jogo: `zoomGrade` (grade) e `zoomFoco` (uma conta) no config.json. `escalaGlobal` (opcional, ex. 0.8) reduz a resolução de tudo para poupar RAM.
